# Monarch WooCommerce Payment Gateway - Feature Updates

## Version 2.15.3
**Date:** January 19, 2026 03:15:00 PM

### Bug Fixes

#### 1. Existing User Credential Handling Fix
- **Issue:** Same email address showing different API credentials across orders (Order 241 vs 242)
- **Root Cause:** When user already exists in Monarch (verify returns 200), the system was not clearing stale purchaser API credentials from previous organization creation
- **Fix:**
  - When `/merchants/verify/{email}` returns 200 (user exists), explicitly clear all purchaser API credentials
  - Existing users now consistently use merchant credentials instead of potentially stale purchaser credentials
  - Clear credentials in both the "user exists" path and the "org creation failed - treat as existing" path
- **Behavior Change:**
  - **NEW users** (first time creating organization): Use purchaser credentials if returned by API
  - **EXISTING users** (verify returns 200): Use merchant credentials (purchaser credentials cleared)

### Files Modified
- `includes/class-wc-monarch-ach-gateway.php` - Clear stale purchaser credentials for existing users
- `woocommerce-monarch-ach.php` - Version bump to 2.15.3

---

## Version 2.15.2
**Date:** January 19, 2026 02:30:00 PM

### Bug Fixes

#### 1. Session Cache Clearing Fix
- **Issue:** Same email address showing different credentials across orders (caching error)
- **Fix:** Clear all Monarch session data at the start of `ajax_create_organization()` before creating new organization
- Prevents old session data from being reused for new transactions
- Clears: org_id, user_id, paytoken_id, temp credentials, registered_email, pending_email, connected_date

#### 2. CRON Status Update Stalling Fix
- **Issue:** "Update Status Now" button stalling when clicked in admin panel
- **Fix:** Added try-catch block and `set_time_limit(120)` to `ajax_manual_status_update()`
- Returns proper error response if exception occurs

### Files Modified
- `includes/class-wc-monarch-ach-gateway.php` - Session cache clearing in ajax_create_organization
- `includes/class-wc-monarch-cron.php` - CRON stalling fix with try-catch and time limit
- `woocommerce-monarch-ach.php` - Version bump to 2.15.2

---

## Version 2.15
**Date:** January 19, 2026 01:04:00 PM

### System Updates

#### 1. Verify Endpoint Hardcoded Credentials
- `/merchants/verify/{email}` endpoint now uses static hardcoded credentials
- **Sandbox:**
  - X-API-KEY: `f493652b-74a7-4767-8b45-f493652111af`
  - X-APP-ID: `c4e41111`
- **Production:**
  - X-API-KEY: `f493652b-74a7-4767-8b45-f4936521112b`
  - X-APP-ID: `c4e4c4f2`
- All other API endpoints use merchant credentials from WooCommerce settings

#### 2. API Logic Flow
- `verify/email` returns **404** → Create new purchaser organization
- `verify/email` returns **200** → Do NOT create organization, use existing purchaser data

#### 3. Guest Checkout Support (Incognito Browser)
- `payment_fields()` supports WC session for guest users
- `validate_fields()` supports both logged-in and guest checkout
- `process_payment()` uses purchaser credentials for guests
- Bank connection data stored in WC session for guests

#### 4. Error Handling
- Organization creation failure treated as existing user
- Simplified error handling without retry loops
- No error messages displayed to users when possible

### API Endpoints

| Endpoint | Credentials Used |
|----------|------------------|
| `/merchants/verify/{email}` | Hardcoded (sandbox/production) |
| `/organization` | Merchant credentials |
| `/transaction/sale` | Merchant credentials |
| `/getlatestpaytoken/{orgId}` | Merchant credentials |
| `/paytoken` | Merchant credentials |

### Files Modified in This Version
- `includes/class-monarch-api.php` - Hardcoded verify credentials
- `includes/class-wc-monarch-ach-gateway.php` - Guest checkout, error handling
- `assets/js/monarch-ach.js` - UI improvements
- `woocommerce-monarch-ach.php` - Version bump

---

## Previous Versions

### Version 2.14
- Initial hardcoded credentials implementation
- Guest checkout support added

### Version 2.13 and earlier
- Dynamic credentials for all endpoints
- Basic checkout functionality
