# Monarch WooCommerce Payment Gateway - Version 2.16

**Release Date:** January 20, 2026

---

## Quick Summary

Version 2.16 fixes critical bugs from the 2.15 series:

| Issue | Status |
|-------|--------|
| Wrong API credentials for verify endpoint | FIXED |
| Same email showing different credentials across orders | FIXED |
| "Update Status Now" button stalling | FIXED |
| Guest checkout not working properly | FIXED |

---

## Bug Fixes Explained

### Bug #1: Verify Endpoint Using Wrong Credentials

**What was happening:**
The `/merchants/verify/{email}` API call was using merchant credentials, but Monarch requires specific hardcoded credentials for this endpoint.

**The fix:**
Now uses static credentials based on environment:

```
SANDBOX:
  X-API-KEY: f493652b-74a7-4767-8b45-f493652111af
  X-APP-ID:  c4e41111

PRODUCTION:
  X-API-KEY: f493652b-74a7-4767-8b45-f4936521112b
  X-APP-ID:  c4e4c4f2
```

**File changed:** `includes/class-monarch-api.php`

---

### Bug #2: Same Email Showing Different Credentials (Caching Issue)

**What was happening:**
When the same customer (e.g., `christian+walterwhite@monarch.is`) placed multiple orders:
- Order 241 had one set of API credentials
- Order 242 had a DIFFERENT set of API credentials

This caused payment failures and confusion.

**Root cause:**
1. First order: New user created → purchaser credentials saved to session
2. Second order: User already exists (verify returns 200) → OLD credentials from session were still being used

**The fix:**
Two-part solution:

1. **Clear session at start:** When "Connect Bank Account" is clicked, ALL old Monarch session data is cleared first

2. **Clear credentials for existing users:** When verify returns 200 (user exists), purchaser credentials are explicitly cleared so merchant credentials are used instead

**Credential usage after fix:**

| Scenario | Credentials Used |
|----------|------------------|
| NEW user (first time) | Purchaser credentials (from API) |
| EXISTING user (verify = 200) | Merchant credentials |

**File changed:** `includes/class-wc-monarch-ach-gateway.php`

---

### Bug #3: "Update Status Now" Button Stalling

**What was happening:**
In WooCommerce → Monarch ACH admin panel, clicking "Update Status Now" would freeze/stall indefinitely.

**The fix:**
- Added error handling (try-catch block)
- Added 2-minute time limit for processing
- Now shows proper error message if something goes wrong

**File changed:** `includes/class-wc-monarch-cron.php`

---

### Bug #4: Guest Checkout Issues

**What was happening:**
Customers checking out without an account (guest checkout) had issues with bank connection data not being saved properly.

**The fix:**
- Session handling improved for guest users
- Bank connection data properly stored in WooCommerce session
- Works correctly in incognito/private browsing

**File changed:** `includes/class-wc-monarch-ach-gateway.php`

---

## How the Payment Flow Works Now

```
Step 1: Customer clicks "Connect Bank Account"
        ↓
Step 2: System clears ALL old session data (prevents caching bugs)
        ↓
Step 3: Call /merchants/verify/{email} with HARDCODED credentials
        ↓
     ┌──────────────────────────────────────┐
     │                                      │
     ↓                                      ↓
Response: 404                         Response: 200
(User NOT found)                      (User EXISTS)
     ↓                                      ↓
Create new organization               Use existing org_id
Save purchaser credentials            Clear purchaser credentials
     ↓                                      ↓
     └──────────────────────────────────────┘
                      ↓
Step 4: Open bank linking (Yodlee)
        ↓
Step 5: Get paytoken after bank connected
        ↓
Step 6: Process payment with /transaction/sale
```

---

## API Credentials Reference

| API Endpoint | Which Credentials? |
|--------------|-------------------|
| `/merchants/verify/{email}` | **Hardcoded** (see above) |
| `/organization` | Merchant credentials |
| `/transaction/sale` | Merchant credentials |
| `/getlatestpaytoken/{orgId}` | Merchant credentials |
| `/paytoken` | Merchant credentials |

---

## Files Changed in 2.16

| File | What Changed |
|------|--------------|
| `woocommerce-monarch-ach.php` | Version number updated to 2.16 |
| `includes/class-monarch-api.php` | Hardcoded credentials for verify endpoint |
| `includes/class-wc-monarch-ach-gateway.php` | Session clearing, credential handling fixes |
| `includes/class-wc-monarch-cron.php` | CRON timeout and error handling |

---

## How to Upgrade

1. **Backup** your current plugin folder
2. **Deactivate** the Monarch ACH plugin in WordPress
3. **Delete** the old `wordpress-payment` folder
4. **Upload** `wordpress-payment-2.16.zip` and extract
5. **Activate** the plugin
6. **Test** with a sandbox transaction

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.16 | Jan 20, 2026 | Consolidated release with all fixes |
| 2.15.3 | Jan 19, 2026 | Existing user credential fix |
| 2.15.2 | Jan 19, 2026 | Session clearing + CRON fix |
| 2.15 | Jan 19, 2026 | Hardcoded verify credentials |
| 2.14 | Earlier | Initial implementation |
